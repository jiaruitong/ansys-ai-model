
#!/usr/bin/env python3
"""Extract structural metrics from an Ansys result file with DPF."""
from __future__ import annotations

import argparse
import json
import math
import sys
from pathlib import Path
from typing import Any, Dict


def _field_max_norm(fields_container) -> float | None:
    max_value = None
    for field in fields_container:
        data = getattr(field, "data", None)
        if data is None:
            continue
        for row in data:
            try:
                # vector row
                value = math.sqrt(sum(float(x) ** 2 for x in row))
            except TypeError:
                # scalar value
                value = abs(float(row))
            if max_value is None or value > max_value:
                max_value = value
    return max_value


def _field_max_scalar(fields_container) -> float | None:
    max_value = None
    for field in fields_container:
        data = getattr(field, "data", None)
        if data is None:
            continue
        for value in data:
            value = float(value)
            if max_value is None or value > max_value:
                max_value = value
    return max_value


def extract_metrics(rst_path: Path, yield_strength_mpa: float | None = None) -> Dict[str, Any]:
    try:
        from ansys.dpf import core as dpf
    except ImportError as exc:
        print("missing ansys-dpf-core. install with: pip install ansys-dpf-core", file=sys.stderr)
        raise SystemExit(2) from exc

    model = dpf.Model(str(rst_path))
    metrics: Dict[str, Any] = {
        "result_file": str(rst_path),
        "available_results": [str(r) for r in getattr(model, "metadata", {}).result_info.available_results],
    }

    try:
        disp_fc = model.results.displacement().eval()
        metrics["max_total_deformation"] = _field_max_norm(disp_fc)
        metrics["max_total_deformation_units"] = "model_units"
    except Exception as exc:
        metrics["max_total_deformation_error"] = str(exc)

    try:
        # API names differ across versions; try the most common accessors.
        if hasattr(model.results, "stress_von_mises"):
            stress_fc = model.results.stress_von_mises().eval()
        elif hasattr(model.results, "equivalent_stress"):
            stress_fc = model.results.equivalent_stress().eval()
        else:
            stress_fc = model.results.stress().von_mises().eval()  # type: ignore[attr-defined]
        max_stress = _field_max_scalar(stress_fc)
        metrics["max_von_mises_stress"] = max_stress
        metrics["max_von_mises_stress_units"] = "model_units"
        if yield_strength_mpa is not None and max_stress and max_stress != 0:
            # If the model uses MPa, this is direct. If it uses Pa, user should pass converted value or adjust units.
            metrics["yield_strength_mpa_input"] = yield_strength_mpa
            metrics["safety_factor_min_using_input_units"] = yield_strength_mpa / max_stress
    except Exception as exc:
        metrics["max_von_mises_stress_error"] = str(exc)

    return metrics


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--rst", required=True, help="path to .rst result file")
    parser.add_argument("--yield-strength-mpa", type=float, help="yield strength for simple safety factor calculation")
    parser.add_argument("--out", required=True, help="output metrics JSON path")
    parser.add_argument("--dry-run", action="store_true", help="validate arguments without importing DPF")
    args = parser.parse_args()

    rst = Path(args.rst).resolve()
    if not rst.exists():
        print(f"result file not found: {rst}", file=sys.stderr)
        return 2
    out = Path(args.out).resolve()
    out.parent.mkdir(parents=True, exist_ok=True)

    if args.dry_run:
        sample = {"result_file": str(rst), "dry_run": True}
        out.write_text(json.dumps(sample, indent=2), encoding="utf-8")
        print(f"wrote dry-run metrics: {out}")
        return 0

    metrics = extract_metrics(rst, args.yield_strength_mpa)
    out.write_text(json.dumps(metrics, indent=2), encoding="utf-8")
    print(f"wrote metrics: {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
