
#!/usr/bin/env python3
"""Create simple STEP geometry for Ansys Mechanical examples using CadQuery.

Supported shapes: beam, block, plate, cylinder.
All dimensions are interpreted in meters unless --units mm is supplied.
"""
from __future__ import annotations

import argparse
from pathlib import Path


def _scale(value: float, units: str) -> float:
    return value / 1000.0 if units.lower() == "mm" else value


def build_shape(args):
    try:
        import cadquery as cq
    except ImportError as exc:
        raise SystemExit(
            "cadquery is required for geometry generation. Install with: pip install cadquery\n"
            "Alternatively, provide an existing STEP/Parasolid/CAD file to Mechanical."
        ) from exc

    shape = args.shape.lower()
    length = _scale(args.length, args.units)
    width = _scale(args.width, args.units)
    height = _scale(args.height, args.units)
    radius = _scale(args.radius, args.units)

    if shape in {"beam", "block", "plate"}:
        # CadQuery dimensions are model units. STEP has no universal unit; document units in the analysis spec.
        return cq.Workplane("XY").box(length, width, height)
    if shape == "cylinder":
        return cq.Workplane("XY").circle(radius).extrude(length)
    raise SystemExit(f"unsupported shape: {args.shape}")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--shape", choices=["beam", "block", "plate", "cylinder"], required=True)
    parser.add_argument("--length", type=float, default=0.2, help="length or cylinder extrusion length")
    parser.add_argument("--width", type=float, default=0.02, help="box/beam width")
    parser.add_argument("--height", type=float, default=0.01, help="box/beam height")
    parser.add_argument("--radius", type=float, default=0.01, help="cylinder radius")
    parser.add_argument("--units", choices=["m", "mm"], default="m", help="input dimension units")
    parser.add_argument("--out", required=True, help="output STEP file path")
    args = parser.parse_args()

    out = Path(args.out).resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    model = build_shape(args)

    import cadquery as cq
    cq.exporters.export(model, str(out))
    print(f"wrote geometry: {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
