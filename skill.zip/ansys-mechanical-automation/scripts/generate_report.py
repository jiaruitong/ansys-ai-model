
#!/usr/bin/env python3
"""Generate a DOCX report and optionally convert it to PDF."""
from __future__ import annotations

import argparse
import json
import shutil
import subprocess
from pathlib import Path
from typing import Any, Dict


def load_metrics(path: Path) -> Dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def add_metric_table(document, metrics: Dict[str, Any]) -> None:
    table = document.add_table(rows=1, cols=2)
    table.style = "Table Grid"
    table.rows[0].cells[0].text = "Metric"
    table.rows[0].cells[1].text = "Value"
    keys = [
        "max_total_deformation",
        "max_total_deformation_units",
        "max_von_mises_stress",
        "max_von_mises_stress_units",
        "yield_strength_mpa_input",
        "safety_factor_min_using_input_units",
        "result_file",
    ]
    for key in keys:
        if key not in metrics:
            continue
        row = table.add_row().cells
        row[0].text = key
        row[1].text = str(metrics[key])


def build_docx(title: str, metrics_path: Path, images_dir: Path | None, out_docx: Path, notes: str | None) -> None:
    try:
        from docx import Document
        from docx.shared import Inches
    except ImportError as exc:
        raise SystemExit("python-docx is required. install with: pip install python-docx") from exc

    metrics = load_metrics(metrics_path)
    document = Document()
    document.add_heading(title, 0)
    document.add_paragraph("Generated from an Ansys Mechanical automation workflow.")

    document.add_heading("1. Summary", level=1)
    if notes:
        document.add_paragraph(notes)
    else:
        document.add_paragraph(
            "This report summarizes the finite element setup, solved result metrics, and exported result images. "
            "Review assumptions, units, material data, boundary conditions, and mesh convergence before using results for design decisions."
        )

    document.add_heading("2. Key metrics", level=1)
    add_metric_table(document, metrics)

    if images_dir and images_dir.exists():
        images = sorted([p for p in images_dir.iterdir() if p.suffix.lower() in {".png", ".jpg", ".jpeg"}])
        if images:
            document.add_heading("3. Result images", level=1)
            for image in images:
                document.add_paragraph(image.stem.replace("_", " ").title())
                try:
                    document.add_picture(str(image), width=Inches(6.0))
                except Exception as exc:
                    document.add_paragraph(f"Could not embed image {image.name}: {exc}")

    document.add_heading("4. Notes and limitations", level=1)
    document.add_paragraph(
        "Peak stress can be mesh-sensitive near constraints, contacts, sharp corners, and singularities. "
        "Safety factor is a simple yield-based estimate only when yield strength and stress units are consistent."
    )

    out_docx.parent.mkdir(parents=True, exist_ok=True)
    document.save(out_docx)


def convert_to_pdf(docx_path: Path) -> Path | None:
    soffice = shutil.which("soffice") or shutil.which("libreoffice")
    if not soffice:
        print("LibreOffice not found; skipping PDF conversion.")
        return None
    cmd = [soffice, "--headless", "--convert-to", "pdf", "--outdir", str(docx_path.parent), str(docx_path)]
    subprocess.run(cmd, check=True)
    pdf = docx_path.with_suffix(".pdf")
    return pdf if pdf.exists() else None


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--title", default="Ansys Mechanical Structural Analysis Report")
    parser.add_argument("--metrics", required=True, help="metrics JSON from extract_dpf_results.py")
    parser.add_argument("--images", help="directory containing exported PNG/JPG result images")
    parser.add_argument("--docx", required=True, help="output DOCX path")
    parser.add_argument("--pdf", action="store_true", help="also convert the DOCX to PDF with LibreOffice if available")
    parser.add_argument("--notes", help="optional summary notes")
    args = parser.parse_args()

    metrics_path = Path(args.metrics).resolve()
    images_dir = Path(args.images).resolve() if args.images else None
    docx_path = Path(args.docx).resolve()
    build_docx(args.title, metrics_path, images_dir, docx_path, args.notes)
    print(f"wrote DOCX: {docx_path}")
    if args.pdf:
        pdf = convert_to_pdf(docx_path)
        if pdf:
            print(f"wrote PDF: {pdf}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
