
#!/usr/bin/env python3
"""Launch or connect to Ansys Mechanical with PyMechanical and run a Mechanical Python script."""
from __future__ import annotations

import argparse
import sys
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--script", required=True, help="Mechanical Python script to execute inside Mechanical")
    parser.add_argument("--output", help="write run_python_script return text to this file")
    parser.add_argument("--version", help="optional Ansys version identifier accepted by PyMechanical")
    parser.add_argument("--port", type=int, help="connect to an already running Mechanical gRPC server port")
    parser.add_argument("--host", default="127.0.0.1", help="host for an already running Mechanical gRPC server")
    parser.add_argument("--no-batch", action="store_true", help="launch Mechanical with visible UI when supported")
    parser.add_argument("--cleanup-on-exit", action="store_true", help="request cleanup on exit for launched sessions")
    parser.add_argument("--dry-run", action="store_true", help="validate arguments without importing PyMechanical")
    args = parser.parse_args()

    script_path = Path(args.script).resolve()
    if not script_path.exists():
        print(f"script not found: {script_path}", file=sys.stderr)
        return 2
    source = script_path.read_text(encoding="utf-8")

    if args.dry_run:
        print(f"dry run ok: {script_path} ({len(source)} characters)")
        return 0

    try:
        from ansys.mechanical.core import launch_mechanical
    except ImportError as exc:
        print("missing ansys-mechanical-core. install with: pip install ansys-mechanical-core", file=sys.stderr)
        raise SystemExit(2) from exc

    mechanical = None
    try:
        if args.port:
            # PyMechanical can connect through launch_mechanical when a port is supplied in supported versions.
            mechanical = launch_mechanical(host=args.host, port=args.port, batch=not args.no_batch)
        else:
            launch_kwargs = {
                "batch": not args.no_batch,
                "cleanup_on_exit": args.cleanup_on_exit,
            }
            if args.version:
                launch_kwargs["version"] = args.version
            mechanical = launch_mechanical(**launch_kwargs)

        print("Mechanical session started.")
        result = mechanical.run_python_script(source)
        if result is None:
            result_text = ""
        else:
            result_text = str(result)
        print(result_text)
        if args.output:
            out = Path(args.output).resolve()
            out.parent.mkdir(parents=True, exist_ok=True)
            out.write_text(result_text, encoding="utf-8")
        return 0
    finally:
        if mechanical is not None:
            try:
                mechanical.exit()
            except Exception:
                pass


if __name__ == "__main__":
    raise SystemExit(main())
