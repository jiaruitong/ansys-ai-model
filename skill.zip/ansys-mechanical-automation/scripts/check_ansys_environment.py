
#!/usr/bin/env python3
"""Check whether the local machine looks ready for Ansys Mechanical automation."""
from __future__ import annotations

import importlib.util
import os
import platform
import shutil
import sys
from pathlib import Path

REQUIRED_IMPORTS = [
    ("ansys.mechanical.core", "ansys-mechanical-core"),
    ("ansys.dpf.core", "ansys-dpf-core"),
]
OPTIONAL_IMPORTS = [
    ("yaml", "pyyaml"),
    ("docx", "python-docx"),
    ("cadquery", "cadquery"),
]


def has_module(name: str) -> bool:
    return importlib.util.find_spec(name) is not None


def main() -> int:
    print("Ansys Mechanical automation environment check")
    print("=" * 52)
    print(f"Python: {sys.version.split()[0]} at {sys.executable}")
    print(f"Platform: {platform.platform()}")
    print()

    ok = True
    print("Python packages:")
    for module, package in REQUIRED_IMPORTS:
        present = has_module(module)
        print(f"  {'OK ' if present else 'MISS'} {module}  pip package: {package}")
        ok = ok and present
    for module, package in OPTIONAL_IMPORTS:
        present = has_module(module)
        print(f"  {'OK ' if present else 'MISS'} {module}  optional package: {package}")
    print()

    print("Common executables:")
    for exe in ["runwb2", "ansysedt", "soffice"]:
        found = shutil.which(exe)
        print(f"  {exe}: {found or 'not found on PATH'}")
    print()

    print("Ansys-related environment variables:")
    keys = sorted(k for k in os.environ if k.startswith(("AWP_ROOT", "ANSYS", "ANSYSLMD")))
    if not keys:
        print("  no AWP_ROOT*/ANSYS*/ANSYSLMD* variables found")
    for key in keys:
        print(f"  {key}={os.environ.get(key)}")
    print()

    possible_roots = []
    for key in keys:
        value = os.environ.get(key)
        if value and Path(value).exists():
            possible_roots.append(Path(value))
    if possible_roots:
        print("Existing Ansys roots:")
        for path in possible_roots:
            print(f"  {path}")
    else:
        print("No existing Ansys root paths detected from environment variables.")
    print()

    if not ok:
        print("Result: environment is missing required Python packages.")
        print("Install with: pip install ansys-mechanical-core ansys-dpf-core pyyaml python-docx")
        return 2

    print("Result: required Python packages are importable. Next, test launching Mechanical with run_mechanical_script.py.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
