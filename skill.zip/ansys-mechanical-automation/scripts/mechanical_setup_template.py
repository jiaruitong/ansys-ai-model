
# Mechanical in-session script template.
# Run this through scripts/run_mechanical_script.py after editing the inputs below.

import os

CAD_PATH = r"C:\path\to\input\model.step"
OUT_DIR = r"C:\path\to\results"
PROJECT_PATH = r"C:\path\to\results\analysis.mechdat"
FIXED_NAMED_SELECTION = "fixed_face"
LOAD_NAMED_SELECTION = "load_face"
FORCE_N = 100.0

os.makedirs(OUT_DIR, exist_ok=True)
os.makedirs(os.path.join(OUT_DIR, "images"), exist_ok=True)

# This template intentionally keeps version-sensitive Mechanical object model calls in one place.
# Patch these calls after testing in the Mechanical scripting console for the installed 2026 R1 build.

def msg(text):
    try:
        ExtAPI.Log.WriteMessage(str(text))
    except Exception:
        print(text)


def get_named_selection(name):
    for child in Model.NamedSelections.Children:
        if child.Name.lower() == name.lower():
            return child
    raise Exception("named selection not found: " + name)

msg("starting mechanical setup")
msg("cad path: " + CAD_PATH)

# Geometry import pattern. Verify exact property names in the local Mechanical scripting console.
try:
    geometry_import = Model.GeometryImportGroup.AddGeometryImport()
    geometry_import.Import(CAD_PATH)
    msg("geometry imported")
except Exception as exc:
    msg("geometry import failed: " + str(exc))
    raise

# Add a static structural analysis.
try:
    analysis = Model.AddStaticStructuralAnalysis()
except Exception:
    analysis = Model.Analyses[0]
msg("analysis ready")

# Boundary conditions using named selections.
fixed_ns = get_named_selection(FIXED_NAMED_SELECTION)
load_ns = get_named_selection(LOAD_NAMED_SELECTION)

try:
    fixed = analysis.AddFixedSupport()
    fixed.Location = fixed_ns
    msg("fixed support applied")
except Exception as exc:
    msg("fixed support failed; patch Location assignment for this Mechanical build: " + str(exc))
    raise

try:
    force = analysis.AddForce()
    force.Location = load_ns
    # Direction and magnitude APIs are release/template-sensitive.
    # Use Mechanical scripting console to patch these lines if required.
    force.DefineBy = LoadDefineBy.Components
    force.YComponent.Output.DiscreteValues = [Quantity(str(-FORCE_N) + " [N]")]
    msg("force applied")
except Exception as exc:
    msg("force creation failed; patch force component API for this Mechanical build: " + str(exc))
    raise

# Mesh and solve.
try:
    Model.Mesh.GenerateMesh()
    msg("mesh generated")
except Exception as exc:
    msg("mesh generation failed: " + str(exc))
    raise

try:
    sol = analysis.Solution
    total_def = sol.AddTotalDeformation()
    eq_stress = sol.AddEquivalentStress()
    analysis.Solve()
    total_def.EvaluateAllResults()
    eq_stress.EvaluateAllResults()
    msg("solve complete")
except Exception as exc:
    msg("solve/results failed: " + str(exc))
    raise

# Save project. Image export APIs are graphics-context sensitive; patch locally if needed.
try:
    ExtAPI.DataModel.Project.SaveAs(PROJECT_PATH)
    msg("project saved: " + PROJECT_PATH)
except Exception as exc:
    msg("project save failed: " + str(exc))

msg("mechanical setup finished")
