---
name: ansys-mechanical-automation
description: automate ansys mechanical and workbench structural simulation workflows from codex. use when the user asks to operate ansys mechanical 2026 r1 or similar versions for geometry creation or cad import, material assignment, boundary conditions, loads, meshing, solving, result image export, maximum stress, maximum displacement, safety factor extraction, or word and pdf report generation through pymechanical and dpf scripts.
---

# Ansys Mechanical Automation

## Overview

Use this skill to help Codex create and run repeatable Ansys Mechanical / Workbench structural simulation workflows on a local or remote machine that already has Ansys Mechanical 2026 R1 installed and licensed.

The skill supports the workflow: understand the structural analysis request -> create or import CAD -> set materials -> apply constraints and loads -> mesh -> solve -> export contour images -> extract maximum stress, displacement, and safety factor -> generate Word/PDF reports.

## Execution Model

Use Python automation as the default control layer:

1. Use `scripts/check_ansys_environment.py` first when the user is unsure whether the local environment can run Ansys automation.
2. Use `scripts/create_simple_geometry.py` for simple beam, plate, cylinder, and block geometry. It exports STEP with CadQuery when available.
3. Use `scripts/run_mechanical_script.py` to launch Ansys Mechanical through PyMechanical and execute a Mechanical Python script.
4. Use `scripts/extract_dpf_results.py` to read solved result files with DPF and extract numeric metrics.
5. Use `scripts/generate_report.py` to build a DOCX report and optionally convert it to PDF when LibreOffice is available.

Never claim that cloud ChatGPT can run Ansys directly. Codex must run on the user's workstation or remote host where Ansys Mechanical 2026 R1, a valid license, and required Python packages are available.

## Default Workflow for a New Simulation

1. Clarify missing physical inputs before writing scripts:
   - analysis type: static structural, modal, thermal stress, etc.
   - geometry source: simple generated geometry or existing CAD file.
   - units.
   - material name and yield strength if safety factor is required.
   - constraints and loads, including faces, named selections, magnitudes, directions, and units.
   - mesh size or refinement requirements.
   - required result plots and report format.

2. Create a run folder with this structure:

```text
run_folder/
  input/
    model.step or original cad file
    analysis_spec.yaml
  mechanical/
    mechanical_setup.py
  results/
    images/
    metrics.json
    report.docx
    report.pdf
```

3. Prefer named selections for boundary conditions. If the CAD has no named selections, either create them in SpaceClaim/Discovery/Workbench before Mechanical, or generate simple geometry where faces can be identified by bounding coordinates. Avoid fragile face index selection unless the user explicitly accepts it.

4. For simple generated geometry, call:

```bash
python scripts/create_simple_geometry.py --shape beam --length 0.2 --width 0.02 --height 0.01 --out run_folder/input/beam.step
```

5. Generate or edit a Mechanical Python script using `references/mechanical-workflow.md` and `references/mechanical-scripting-patterns.md`.

6. Run Mechanical:

```bash
python scripts/run_mechanical_script.py --script run_folder/mechanical/mechanical_setup.py --output run_folder/results/mechanical_run_output.txt
```

7. Extract solved result metrics from the generated `.rst` file:

```bash
python scripts/extract_dpf_results.py --rst run_folder/results/file.rst --yield-strength-mpa 250 --out run_folder/results/metrics.json
```

8. Generate the report:

```bash
python scripts/generate_report.py --title "static structural report" --metrics run_folder/results/metrics.json --images run_folder/results/images --docx run_folder/results/report.docx --pdf
```

## Task Routing

Use these task routes:

- **environment or installation issues**: run or inspect `scripts/check_ansys_environment.py`, then consult `references/troubleshooting.md`.
- **simple geometry creation**: use `scripts/create_simple_geometry.py`; if geometry is complex, ask the user for CAD or use their existing CAD path.
- **Mechanical automation script creation**: use `references/mechanical-workflow.md` and `references/mechanical-scripting-patterns.md`.
- **postprocessing and metric extraction**: use `scripts/extract_dpf_results.py` and `references/dpf-postprocess.md`.
- **report generation**: use `scripts/generate_report.py` and write conclusions from metrics and images.

## Important Guardrails

- Treat Ansys Mechanical API calls as version-sensitive. For 2026 R1, prefer PyMechanical plus in-Mechanical Python, and validate generated scripts on the user's machine.
- Do not hide uncertainty when a Mechanical object model call may vary by release or template. Add a small probe script or use Mechanical scripting console introspection.
- Prefer named selections over guessed geometry indices.
- Keep units explicit in every script and report.
- Use conservative result language: extracted maxima depend on mesh, material assumptions, and boundary condition fidelity.
- For safety factor, require yield strength or state that safety factor cannot be computed.
- Keep user CAD paths and output paths configurable. Avoid hard-coded local paths except inside examples.

## Common User Requests and Responses

### Request: create a cantilever beam static structural model

Create STEP geometry with `create_simple_geometry.py`, generate a Mechanical setup script that imports the STEP file, assign material, fix the left end face, apply a force or pressure on the right end face, mesh, solve, export total deformation and equivalent stress images, extract maximum total deformation and von Mises stress, then generate a report.

### Request: import my CAD and apply loads

Ask for the CAD path and named selection names for fixed support and load faces. If there are no named selections, ask the user to provide a screenshot or define coordinate-based face rules. Generate a Mechanical script that imports the CAD, binds boundary conditions to the named selections, solves, and exports results.

### Request: generate a PDF report

Generate a DOCX report first with `scripts/generate_report.py`, then convert to PDF if LibreOffice is installed. If PDF conversion fails, deliver the DOCX and the metrics/images, and explain that local LibreOffice is needed for automatic PDF export.
