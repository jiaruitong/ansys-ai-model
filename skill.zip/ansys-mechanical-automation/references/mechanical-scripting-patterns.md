# Mechanical Scripting Patterns

## PyMechanical outer script

Use `scripts/run_mechanical_script.py` as the outer launcher. It starts or connects to Mechanical and sends an in-Mechanical Python script with `run_python_script`.

Outer Python should not contain Mechanical object model calls except through `mechanical.run_python_script(...)`. Keep Mechanical API code in a separate script such as `mechanical_setup.py` so it can be pasted into Mechanical scripting console for debugging.

## In-Mechanical script structure

Use this layout for `mechanical_setup.py`:

```python
import os

# 1. user inputs
CAD_PATH = r"C:\path	o\model.step"
OUT_DIR = r"C:\path	oesults"
PROJECT_PATH = r"C:\path	o\project.mechdat"

# 2. helpers
# - ensure folders exist
# - find named selections
# - fail loudly if a selection is missing

# 3. geometry import
# 4. materials and assignments
# 5. analysis creation
# 6. supports and loads
# 7. mesh controls
# 8. solve
# 9. result objects and image export
# 10. save project
```

## Named selection helper pattern

Inside Mechanical, always write helpers that fail loudly:

```python
def get_named_selection(name):
    for child in Model.NamedSelections.Children:
        if child.Name.lower() == name.lower():
            return child
    raise Exception("named selection not found: " + name)
```

When applying a support or load, set its location to the named selection object or its location property according to the verified Mechanical API for the current release.

## Image export pattern

Use Mechanical graphics export when available. If a specific export API changes, leave a clear fallback comment and instruct the user to test the graphics line in Mechanical scripting console.

Common image targets:

```text
results/images/mesh.png
results/images/equivalent_stress.png
results/images/total_deformation.png
results/images/safety_factor.png
```

## Material pattern

For library materials, use the standard material name when available, for example Structural Steel. For custom materials, define elastic modulus, Poisson ratio, density if needed, and yield strength for safety factor. Mechanical material APIs vary; if material creation fails, keep the analysis running with a verified Engineering Data material and document the assumption in the report.

## Mesh pattern

Set a global element size first. Add local mesh controls only when the user asks for refinement or when stress concentration is expected.

Always report mesh settings in the final report. Do not treat peak stress near singular constraints as design stress without mesh convergence context.

## Solve pattern

For long solves, run Mechanical in batch mode when possible. After solving, evaluate result objects before exporting images. Save the project after solve so the user can inspect it in GUI.

## Result reliability rules

- Maximum stress near a fixed support or sharp re-entrant corner may be singular.
- Safety factor is meaningful only when yield strength and stress measure are appropriate for the material.
- Linear static analysis assumes small deformation and linear elastic material unless explicitly changed.
- Add mesh convergence notes when the user is making design decisions.
