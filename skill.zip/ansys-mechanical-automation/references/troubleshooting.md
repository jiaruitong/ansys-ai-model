# Troubleshooting Ansys Mechanical Automation

## PyMechanical cannot launch Mechanical

Check:

1. Ansys Mechanical 2026 R1 is installed.
2. A valid Ansys license is available.
3. Python can import `ansys.mechanical.core`.
4. The Mechanical executable path is discoverable or provided in environment variables.
5. Codex is running on the same Windows/Linux workstation or a host with access to Mechanical.

Run:

```bash
python scripts/check_ansys_environment.py
```

## Script works in GUI but fails in batch

Some graphics export and UI-related calls require visible Mechanical. Re-run with batch disabled if images fail:

```bash
python scripts/run_mechanical_script.py --script mechanical_setup.py --no-batch
```

## CAD import fails

Check:

- absolute CAD path,
- file extension supported by the local Ansys installation,
- CAD translator licensing,
- whether the file is open or locked,
- whether the geometry has valid solids rather than surfaces only.

## Boundary condition cannot find a face

Use named selections. If named selections are missing, create them in SpaceClaim/Discovery/Workbench or implement coordinate-based selection with a tolerance and validation count.

## Result image export fails

First ensure the solve succeeded and the result object evaluated. If graphics export API calls differ by Ansys release, export images from the GUI once and patch the script with the verified command.

## DPF extraction fails

Check that the result file exists and is not empty. Search the solve directory for `.rst`. Use the Mechanical project tree to confirm that stress and displacement results were requested and solved.

## PDF report conversion fails

DOCX generation can still succeed without LibreOffice. Install LibreOffice and ensure `soffice` is on PATH for automatic PDF conversion.
