# Mechanical / Workbench Structural Workflow

## Purpose

Use this reference when creating Ansys Mechanical 2026 R1 structural simulation automation scripts. The goal is to make Codex produce scripts that can be run on a workstation with Ansys installed, not merely describe GUI clicks.

## Recommended local prerequisites

Install Ansys Mechanical 2026 R1 and verify licensing. In the Python environment used by Codex, install these packages when needed:

```bash
pip install ansys-mechanical-core ansys-dpf-core pyyaml python-docx cadquery
```

`cadquery` is only needed for simple STEP geometry generation. `python-docx` is only needed for Word reports. LibreOffice is needed only when converting DOCX to PDF with `scripts/generate_report.py --pdf`.

## Standard run sequence

1. Create a project folder.
2. Prepare geometry:
   - Use existing CAD when the user provides STEP, Parasolid, IGES, SCDOC, SCDOCX, or another supported Ansys CAD format.
   - For simple examples, generate STEP with `scripts/create_simple_geometry.py`.
3. Create a Mechanical Python script in `mechanical/mechanical_setup.py`.
4. Launch Mechanical with PyMechanical using `scripts/run_mechanical_script.py`.
5. Inside Mechanical, the script should:
   - import geometry,
   - set units,
   - create or assign material,
   - create named selections or resolve existing named selections,
   - add a Static Structural analysis,
   - apply supports and loads,
   - create mesh settings,
   - solve,
   - create result objects,
   - evaluate results,
   - export contour images,
   - save the project.
6. Locate the result file such as `.rst`.
7. Use DPF to extract reliable numeric metrics.
8. Generate a DOCX/PDF report.

## Input specification pattern

Prefer collecting user requirements in a small YAML file before coding:

```yaml
analysis:
  type: static_structural
  units: mm_n_s_mpa
geometry:
  mode: import
  cad_path: input/model.step
material:
  name: structural_steel
  youngs_modulus_mpa: 200000
  poisson_ratio: 0.3
  yield_strength_mpa: 250
mesh:
  element_size_mm: 2.0
boundary_conditions:
  fixed_support:
    named_selection: fixed_face
loads:
  force:
    named_selection: load_face
    magnitude_n: 100
    direction: [0, -1, 0]
results:
  export_images: true
  request:
    - total_deformation
    - equivalent_stress
    - safety_factor
```

## Geometry strategy

Mechanical is primarily the analysis environment. For geometry creation:

- Use existing CAD whenever possible.
- Use `create_simple_geometry.py` for simple STEP geometry.
- For production geometry, prefer SpaceClaim/Discovery/pyansys-geometry or a CAD system before importing into Mechanical.
- Do not promise robust free-form solid modeling inside Mechanical itself.

## Boundary condition strategy

Prefer named selections. This keeps scripts stable across CAD updates.

Good:

```text
fixed_support.named_selection = "fixed_face"
force.named_selection = "load_face"
```

Risky:

```text
first face in body, face index 0, largest x face without verification
```

Coordinate-based face selection can be used for simple generated geometry, but the script must include tolerance checks and fail loudly when no face or multiple unexpected faces are found.

## Results to export

For a basic static structural report, export:

- equivalent von Mises stress contour,
- total deformation contour,
- safety factor contour when yield strength is available,
- mesh image,
- optional reaction force summary.

Also extract numeric metrics into JSON:

```json
{
  "max_total_deformation_m": 0.0,
  "max_von_mises_stress_pa": 0.0,
  "yield_strength_pa": 250000000.0,
  "safety_factor_min": 0.0,
  "result_file": "path/to/file.rst"
}
```

## What to do when Mechanical API names differ

Generated scripts should be treated as a first pass. If they fail:

1. Keep the PyMechanical launcher script unchanged.
2. Open the failing Mechanical script and patch only the object model call that failed.
3. Add a small introspection line such as `dir(obj)` or `ExtAPI.Log.WriteMessage(str(type(obj)))` inside Mechanical.
4. Re-run the smallest failing step before solving the whole model again.
5. Update the generated script comments with the verified API call for that Ansys build.
