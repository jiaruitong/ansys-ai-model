# DPF Postprocessing

Use this reference when extracting numeric metrics from Ansys result files after the Mechanical solve.

## Preferred script

Use:

```bash
python scripts/extract_dpf_results.py --rst results/file.rst --yield-strength-mpa 250 --out results/metrics.json
```

The script attempts to extract:

- maximum total displacement,
- maximum von Mises stress,
- minimum safety factor when yield strength is supplied,
- unit metadata when available.

## Why DPF

Mechanical contour labels are useful for images, but DPF gives a scriptable, repeatable way to read result data from `.rst` files. Use DPF metrics for report tables.

## Safety factor

For ductile linear elastic analysis, a basic safety factor estimate can be computed as:

```text
safety_factor = yield_strength / max_von_mises_stress
```

Only compute it when yield strength is known. If the material is brittle, nonlinear, temperature-dependent, composite, fatigue-critical, or contact-dominated, state that this simple safety factor is not sufficient.

## Common issues

- If DPF cannot find a result, verify the result file path and whether the solve completed.
- If stress data is unavailable, ensure the Mechanical analysis requested stress results before solving.
- If unit conversion is unclear, keep units from the result file and write them explicitly in the report.
